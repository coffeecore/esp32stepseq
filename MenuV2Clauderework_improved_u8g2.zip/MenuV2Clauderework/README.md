# Menu V2

Petite bibliothèque de menus pour microcontrôleurs (notamment ESP32), entièrement **header-only**.

L'objectif est de séparer clairement :

- la **définition des menus** ;
- la **navigation** ;
- la **modification des valeurs** ;
- le **rendu graphique**.

La bibliothèque ne dépend d'aucun framework graphique et ne dessine rien. Elle peut donc être utilisée avec un écran OLED, TFT, LCD, ou n'importe quel autre système de rendu.

---

## Philosophie

La bibliothèque est conçue pour un microcontrôleur :

- pas de `std::vector` ;
- pas d'allocation dynamique pour les items ;
- nombre maximal d'items connu à l'avance ;
- pile de navigation de taille fixe ;
- les menus sont possédés par le code de l'application ;
- `MenuManager` ne possède aucun menu ;
- le `MenuManager` ne connaît pas le système graphique.

Le principe général est :

```text
┌─────────────────────────────────────────────┐
│                 APPLICATION                 │
│                                             │
│  Menu settings;                             │
│  Menu midi;                                 │
│  MenuManager manager;                       │
│                                             │
│  ┌──────────────┐       ┌───────────────┐   │
│  │    Menu      │       │ MenuManager   │   │
│  │ items        │◄──────│ navigation    │   │
│  │ descriptors  │       │ stack         │   │
│  └──────────────┘       └───────────────┘   │
│           │                    │            │
│           └──────────┬─────────┘            │
│                      ▼                      │
│                TON RENDERER                 │
└─────────────────────────────────────────────┘
```

---

# Les fichiers

## `MenuType.h`

Contient :

- `MenuType`
- `MenuValue`
- `MenuDescriptor`
- `BoolDescriptor`
- `IntDescriptor`
- `FloatDescriptor`
- `EnumDescriptor`
- `EnumOption`
- les callbacks de formatage

Les descriptors savent :

1. modifier une valeur avec `next()` / `prev()` ;
2. formater une valeur pour l'affichage.

Le `MenuManager` n'a donc pas besoin de connaître les détails de chaque type.

---

## `MenuItem.h`

Contient la structure d'un item :

```cpp
struct MenuItem {
    const char* label;
    MenuType type;
    MenuValue value;
    const MenuDescriptor* descriptor;
    MenuCallback callback;
    Menu* submenu;
};
```

Selon le type de l'item, certains champs sont utilisés :

| Type | Label | Value | Descriptor | Callback | Submenu |
|---|---|---|---|---|---|
| `ACTION` | oui | non | non | oui | non |
| `SUBMENU` | oui | non | non | non | oui |
| `BOOL` | oui | oui | oui | non | non |
| `INT` | oui | oui | oui | non | non |
| `FLOAT` | oui | oui | oui | non | non |
| `ENUM` | oui | oui | oui | non | non |
| `LABEL` | oui | non | non | non | non |
| `SEPARATOR` | non | non | non | non | non |

---

## `Menu.h`

Stocke une liste fixe de `MenuItem`.

Par défaut :

```cpp
Menu::MAX_ITEMS == 16
```

Un menu peut être construit avec les helpers :

```cpp
menu.addAction(...);
menu.addSubmenu(...);
menu.addBool(...);
menu.addInt(...);
menu.addFloat(...);
menu.addEnum(...);
menu.addLabel(...);
menu.addSeparator();
```

---

## `MenuManager.h`

Gère :

- la sélection ;
- `next()` / `prev()` ;
- le mode `Browsing` ;
- le mode `Editing` ;
- l'entrée dans les sous-menus ;
- le retour arrière ;
- la pile de menus ;
- la restauration de la sélection du menu parent.

Il ne dessine rien.

---

# Les deux états du MenuManager

Le manager possède deux états :

```cpp
enum class MenuState : uint8_t {
    Browsing,
    Editing
};
```

## Browsing

`next()` et `prev()` déplacent la sélection.

```text
Settings

> Volume
  Brightness
  MIDI
  Reset
```

Après `next()` :

```text
Settings

  Volume
> Brightness
  MIDI
  Reset
```

---

## Editing

Après `enter()` sur une valeur éditable, `next()` et `prev()` modifient la valeur.

```text
Settings

> Volume     80
  Brightness 50
  MIDI
  Reset
```

Après `enter()` :

```text
Settings

> Volume     [80]
  Brightness 50
  MIDI
  Reset
```

Après `next()` :

```text
Settings

> Volume     [81]
  Brightness 50
  MIDI
  Reset
```

Après `back()` :

```text
Settings

> Volume     81
  Brightness 50
  MIDI
  Reset
```

`back()` quitte d'abord le mode `Editing`.

Il ne réalise pas d'annulation : les modifications effectuées restent appliquées.

---

# Exemple complet

```cpp
#include "MenuManager.h"

enum class ClockSource : uint8_t {
    Internal,
    MIDI,
    USB
};

bool enabled = true;
int32_t tempo = 120;
float volume = 0.75f;

uint8_t clockSource =
    static_cast<uint8_t>(ClockSource::Internal);

constexpr EnumOption clockOptions[] = {
    {
        static_cast<uint8_t>(ClockSource::Internal),
        "Internal"
    },
    {
        static_cast<uint8_t>(ClockSource::MIDI),
        "MIDI"
    },
    {
        static_cast<uint8_t>(ClockSource::USB),
        "USB"
    }
};

constexpr BoolDescriptor enabledDescriptor(
    "ON",
    "OFF"
);

constexpr IntDescriptor tempoDescriptor(
    20,
    300,
    1
);

constexpr FloatDescriptor volumeDescriptor(
    0.0f,
    1.0f,
    0.05f
);

constexpr EnumDescriptor clockDescriptor(
    clockOptions,
    3
);

Menu midi("MIDI");
Menu settings("Settings");

MenuManager manager;

void setupMenu()
{
    midi.addEnum(
        "Clock",
        &clockSource,
        &clockDescriptor
    );

    settings.addBool(
        "Enabled",
        &enabled,
        &enabledDescriptor
    );

    settings.addInt(
        "Tempo",
        &tempo,
        &tempoDescriptor
    );

    settings.addFloat(
        "Volume",
        &volume,
        &volumeDescriptor
    );

    settings.addSubmenu(
        "MIDI",
        &midi
    );

    manager.begin(&settings);
}
```

Rendu initial :

```text
Settings

> Enabled    ON
  Tempo      120
  Volume     0.75
  MIDI
```

---

# `BOOL`

Un booléen ne possède pas de mode `Editing`.

Un `enter()` bascule immédiatement sa valeur.

```cpp
bool enabled = true;

constexpr BoolDescriptor descriptor(
    "ON",
    "OFF"
);

menu.addBool(
    "Enabled",
    &enabled,
    &descriptor
);
```

Rendu :

```text
Settings

> Enabled    ON
  Volume     0.75
```

Après `enter()` :

```text
Settings

> Enabled    OFF
  Volume     0.75
```

Un deuxième `enter()` :

```text
Settings

> Enabled    ON
  Volume     0.75
```

`next()` et `prev()` sont équivalents pour un booléen.

---

# `INT`

Un entier possède :

- une valeur minimale ;
- une valeur maximale ;
- un pas.

```cpp
int32_t tempo = 120;

constexpr IntDescriptor descriptor(
    20,     // min
    300,    // max
    1       // step
);

menu.addInt(
    "Tempo",
    &tempo,
    &descriptor
);
```

Rendu :

```text
Settings

> Tempo      120
  Volume     0.75
```

Après `enter()` :

```text
Settings

> Tempo     [120]
  Volume     0.75
```

Après `next()` :

```text
Settings

> Tempo     [121]
  Volume     0.75
```

Après `prev()` :

```text
Settings

> Tempo     [120]
  Volume     0.75
```

La valeur est limitée par `min` et `max`.

```text
300 + next() -> 300
20  - prev() -> 20
```

Il n'y a pas de boucle circulaire pour les entiers.

---

# `FLOAT`

```cpp
float volume = 0.75f;

constexpr FloatDescriptor descriptor(
    0.0f,
    1.0f,
    0.05f
);

menu.addFloat(
    "Volume",
    &volume,
    &descriptor
);
```

Rendu :

```text
Settings

> Volume     0.75
  Tempo      120
```

Après `enter()` :

```text
Settings

> Volume    [0.75]
  Tempo      120
```

Après `next()` :

```text
Settings

> Volume    [0.80]
  Tempo      120
```

Le format par défaut utilise deux décimales.

---

# `ENUM`

Les enums utilisent une liste explicite d'options.

```cpp
enum class ClockSource : uint8_t {
    Internal,
    MIDI,
    USB
};

uint8_t clockSource =
    static_cast<uint8_t>(ClockSource::Internal);

constexpr EnumOption options[] = {
    {
        static_cast<uint8_t>(ClockSource::Internal),
        "Internal"
    },
    {
        static_cast<uint8_t>(ClockSource::MIDI),
        "MIDI"
    },
    {
        static_cast<uint8_t>(ClockSource::USB),
        "USB"
    }
};

constexpr EnumDescriptor descriptor(
    options,
    3
);

menu.addEnum(
    "Clock",
    &clockSource,
    &descriptor
);
```

Rendu initial :

```text
MIDI

> Clock      Internal
```

Après `enter()` :

```text
MIDI

> Clock     [Internal]
```

Après `next()` :

```text
MIDI

> Clock     [MIDI]
```

Après `next()` :

```text
MIDI

> Clock     [USB]
```

Après `next()` :

```text
MIDI

> Clock     [Internal]
```

Les enums sont circulaires.

`prev()` fonctionne également en boucle :

```text
Internal
   ▲
   │
USB ◄── MIDI
```

Plus précisément :

```text
next : Internal -> MIDI -> USB -> Internal

prev : Internal <- MIDI <- USB <- Internal
```

---

# `ACTION`

Une action déclenche un callback.

```cpp
void resetSettings(MenuManager& manager)
{
    tempo = 120;
    volume = 0.75f;
}

menu.addAction(
    "Reset",
    resetSettings
);
```

Rendu :

```text
Settings

  Tempo      120
  Volume     0.75
> Reset
```

Après `enter()` :

```text
resetSettings(manager);
```

Le callback reçoit le `MenuManager`.

Il peut donc aussi naviguer :

```cpp
void openSomething(MenuManager& manager)
{
    manager.reset();
}
```

---

# `SUBMENU`

Un sous-menu est simplement un autre objet `Menu`.

```cpp
Menu settings("Settings");
Menu midi("MIDI");

midi.addEnum(
    "Clock",
    &clockSource,
    &clockDescriptor
);

settings.addSubmenu(
    "MIDI",
    &midi
);
```

Rendu :

```text
Settings

  Tempo      120
> MIDI
  Reset
```

Après `enter()` :

```text
MIDI

> Clock      Internal
```

La pile est alors :

```text
depth 0:
Settings
selected = MIDI

depth 1:
MIDI
selected = Clock
```

Si on appelle `back()` :

```text
Settings

  Tempo      120
> MIDI
  Reset
```

La sélection `MIDI` est restaurée.

Le `Menu` n'a donc pas besoin de connaître son parent.

---

# Navigation avec plusieurs sous-menus

Il est possible d'imbriquer plusieurs menus :

```text
Settings
    │
    └── MIDI
          │
          └── Advanced
                │
                └── Clock
```

Exemple :

```text
Settings

> MIDI
  Audio
```

Après `enter()` :

```text
MIDI

> Advanced
  Clock
```

Après `enter()` :

```text
Advanced

> Clock       Internal
  Channel     1
```

La pile est :

```text
depth 0 -> Settings
depth 1 -> MIDI
depth 2 -> Advanced
```

Avec `MAX_DEPTH == 8`, la profondeur maximale est limitée afin de conserver une mémoire prévisible.

---

# `LABEL`

Un label est un élément informatif.

```cpp
menu.addLabel("Audio Settings");
```

Rendu :

```text
Settings

  Audio Settings
> Volume        0.75
  Balance       0.00
```

Un label n'est pas interactif.

Si le curseur arrive dessus, `enter()` ne fait rien.

---

# `SEPARATOR`

Un séparateur permet d'organiser visuellement un menu.

```cpp
menu.addSeparator();
```

Exemple :

```text
Settings

  Audio
  Volume        0.75
  Balance       0.00
  ----------------
  MIDI
> Clock         Internal
```

Le séparateur n'est pas interactif.

---

# Mélanger tous les types

Un menu réel peut mélanger tous les types :

```cpp
Menu settings("Settings");

settings.addLabel("General");

settings.addBool(
    "Enabled",
    &enabled,
    &enabledDescriptor
);

settings.addInt(
    "Tempo",
    &tempo,
    &tempoDescriptor
);

settings.addSeparator();

settings.addLabel("Audio");

settings.addFloat(
    "Volume",
    &volume,
    &volumeDescriptor
);

settings.addSubmenu(
    "MIDI",
    &midi
);

settings.addAction(
    "Reset",
    resetSettings
);
```

Rendu possible :

```text
Settings

  General
> Enabled       ON
  Tempo         120
  ----------------
  Audio
  Volume        0.75
  MIDI
  Reset
```

---

# Rendu dans un Screen

Le `MenuManager` ne dessine rien.

Le Screen décide comment dessiner.

Exemple simple :

```cpp
void drawMenu(MenuManager& manager)
{
    Menu* menu = manager.currentMenu();

    for (uint8_t i = 0; i < menu->count(); ++i) {
        MenuItem& item = menu->item(i);

        bool selected =
            i == manager.selectedIndex();

        drawItem(
            item,
            selected,
            manager.isEditing()
        );
    }
}
```

Le renderer peut ensuite produire :

```text
┌────────────────────────┐
│ Settings               │
├────────────────────────┤
│   Enabled       ON     │
│ > Tempo        [120]   │
│   Volume         0.75  │
│   MIDI                 │
└────────────────────────┘
```

Le crochet `[120]` est uniquement une convention de rendu.

La bibliothèque ne l'impose pas.

---

# Afficher la valeur d'un item

Pour un item avec descriptor :

```cpp
char buffer[32];

MenuItem* item =
    manager.currentItem();

if (
    item &&
    item->descriptor
) {
    const char* text =
        item->descriptor->format(
            item->value,
            buffer,
            sizeof(buffer)
        );
}
```

Exemples de résultats :

```text
BOOL   -> "ON"
INT    -> "120"
FLOAT  -> "0.75"
ENUM   -> "MIDI"
```

---

# Afficher tous les items

Un renderer typique peut faire :

```cpp
void drawMenu(MenuManager& manager)
{
    Menu* menu = manager.currentMenu();

    for (
        uint8_t i = 0;
        i < menu->count();
        ++i
    ) {
        MenuItem& item =
            menu->item(i);

        bool selected =
            i == manager.selectedIndex();

        char buffer[32];

        const char* value = nullptr;

        if (
            item.descriptor &&
            item.value.ptr
        ) {
            value =
                item.descriptor->format(
                    item.value,
                    buffer,
                    sizeof(buffer)
                );
        }

        drawRow(
            item.label,
            value,
            selected,
            manager.isEditing()
        );
    }
}
```

Ce renderer pourrait produire :

```text
Settings

  General
> Enabled       ON
  Tempo         120
  Volume        0.75
  ----------------
  MIDI
  Reset
```

---

# Formatage personnalisé

Les descriptors peuvent recevoir un formatter.

## Entier

```cpp
void formatBpm(
    char* buffer,
    size_t size,
    int32_t value
)
{
    snprintf(
        buffer,
        size,
        "%ld BPM",
        (long)value
    );
}

constexpr IntDescriptor tempoDescriptor(
    20,
    300,
    1,
    formatBpm
);
```

Au lieu de :

```text
Tempo    120
```

le rendu devient :

```text
Tempo    120 BPM
```

---

## Float

```cpp
void formatDb(
    char* buffer,
    size_t size,
    float value
)
{
    snprintf(
        buffer,
        size,
        "%.1f dB",
        (double)value
    );
}
```

```cpp
constexpr FloatDescriptor volumeDescriptor(
    -60.0f,
    6.0f,
    0.5f,
    formatDb
);
```

Rendu :

```text
Volume    -12.5 dB
```

---

## Bool

```cpp
const char* formatEnabled(
    bool value
)
{
    return value
        ? "Enabled"
        : "Disabled";
}

constexpr BoolDescriptor descriptor(
    "ON",
    "OFF",
    formatEnabled
);
```

Rendu :

```text
Enabled    Enabled
```

ou :

```text
Enabled    Disabled
```

---

# Navigation typique depuis les contrôles physiques

La bibliothèque peut être reliée à n'importe quel système d'entrée :

```cpp
void onNext()
{
    manager.next();
}

void onPrev()
{
    manager.prev();
}

void onEnter()
{
    manager.enter();
}

void onBack()
{
    manager.back();
}
```

Par exemple :

```text
ENCODER ROTATION RIGHT
        │
        ▼
manager.next()

ENCODER ROTATION LEFT
        │
        ▼
manager.prev()

ENCODER PRESS
        │
        ▼
manager.enter()

BACK BUTTON
        │
        ▼
manager.back()
```

---

# Exemple de séquence complète

Menu initial :

```text
Settings

> Enabled       ON
  Tempo         120
  MIDI
```

### `next()`

```text
Settings

  Enabled       ON
> Tempo         120
  MIDI
```

### `enter()`

Le manager passe en `Editing` :

```text
Settings

  Enabled       ON
> Tempo        [120]
  MIDI
```

### `next()`

```text
Settings

  Enabled       ON
> Tempo        [121]
  MIDI
```

### `next()`

```text
Settings

  Enabled       ON
> Tempo        [122]
  MIDI
```

### `back()`

Retour au mode `Browsing` :

```text
Settings

  Enabled       ON
> Tempo         122
  MIDI
```

### `next()`

```text
Settings

  Enabled       ON
  Tempo         122
> MIDI
```

### `enter()`

Entrée dans le sous-menu :

```text
MIDI

> Clock         Internal
```

### `next()`

En mode `Browsing`, la sélection se déplace :

```text
MIDI

> Clock         Internal
```

S'il n'y a qu'un item, la sélection reste sur cet item.

### `enter()`

```text
MIDI

> Clock        [Internal]
```

### `next()`

```text
MIDI

> Clock        [MIDI]
```

### `back()`

Quitte l'édition :

```text
MIDI

> Clock         MIDI
```

### `back()`

Retour au menu parent :

```text
Settings

  Enabled       ON
  Tempo         122
> MIDI
```

La sélection `MIDI` a été restaurée.

---

# Résumé des comportements

| Item | `next()` / `prev()` en Browsing | `enter()` | `next()` / `prev()` en Editing |
|---|---|---|---|
| `ACTION` | change la sélection | exécute le callback | — |
| `SUBMENU` | change la sélection | entre dans le menu | — |
| `BOOL` | change la sélection | bascule immédiatement | — |
| `INT` | change la sélection | entre en édition | modifie la valeur |
| `FLOAT` | change la sélection | entre en édition | modifie la valeur |
| `ENUM` | change la sélection | entre en édition | change l'option |
| `LABEL` | change la sélection | ne fait rien | — |
| `SEPARATOR` | change la sélection | ne fait rien | — |

---

# Important : la bibliothèque ne possède pas les menus

Ceci est valide :

```cpp
Menu settings("Settings");
Menu midi("MIDI");

MenuManager manager;
```

Puis :

```cpp
manager.begin(&settings);
```

Les objets `Menu` doivent rester vivants tant que le `MenuManager` les utilise.

Il faut donc éviter :

```cpp
void createMenu()
{
    Menu temporary("Temporary");

    manager.begin(&temporary);
}
```

Après le retour de `createMenu()`, `temporary` n'existe plus.

Préférer :

```cpp
Menu temporary("Temporary");

void setup()
{
    manager.begin(&temporary);
}
```

ou utiliser des membres d'une classe `Screen`.

---

---

# Intégration avec U8g2 et un OLED SSD1306 128×64

La bibliothèque de menus ne dessine rien elle-même. Dans ton architecture, le rendu doit rester dans le `Screen`.

```text
INPUT
  │
  ▼
SCREEN
  │
  ├── MenuManager
  │     ├── sélection
  │     ├── édition
  │     └── navigation
  │
  └── U8g2
        │
        ▼
      SSD1306
      128×64
```

Le `Screen` reçoit les événements, appelle le `MenuManager`, puis dessine le menu avec U8g2.

---

## Configuration du SSD1306

Exemple pour un écran SSD1306 128×64 en I2C :

```cpp
#include <U8g2lib.h>

U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(
    U8G2_R0,
    U8X8_PIN_NONE
);
```

Puis :

```cpp
void setup()
{
    u8g2.begin();

    setupMenu();

    menuManager.begin(
        &settings
    );
}
```

Le constructeur exact peut varier selon ton câblage et le type de buffer utilisé.

---

## Organisation de l'écran 128×64

Avec :

```cpp
u8g2_font_6x10_tf
```

un rendu simple peut utiliser :

```text
y =  9  : titre
y = 11  : séparation

y = 21  : item 0
y = 31  : item 1
y = 41  : item 2
y = 51  : item 3
y = 61  : item 4
```

Exemple :

```text
┌──────────────────────────────┐
│ Settings                     │
├──────────────────────────────┤
│ > Enabled              ON    │
│   Tempo               120    │
│   Volume             0.75    │
│   MIDI                       │
│   Reset                      │
└──────────────────────────────┘
```

Sur un écran 128×64, il est préférable de garder le renderer simple et prévisible.

---

## Exemple de Screen

Le rendu appartient au `Screen` :

```cpp
class SettingsScreen
{
public:
    Menu settings;
    Menu midi;
    MenuManager menuManager;

    SettingsScreen()
        : settings("Settings"),
          midi("MIDI")
    {
        setupMenu();

        menuManager.begin(
            &settings
        );
    }

    void draw()
    {
        u8g2.clearBuffer();

        drawMenu();

        u8g2.sendBuffer();
    }

private:
    void drawMenu();
};
```

Le `MenuManager` ne connaît donc pas `U8g2`.

---

## Renderer complet pour un OLED 128×64

Voici un exemple directement utilisable comme base dans ton `Screen` :

```cpp
void SettingsScreen::drawMenu()
{
    Menu* menu =
        menuManager.currentMenu();

    if (!menu) {
        return;
    }

    constexpr uint8_t FIRST_ROW = 21;
    constexpr uint8_t ROW_HEIGHT = 10;

    u8g2.setFont(
        u8g2_font_6x10_tf
    );

    // Title
    u8g2.drawStr(
        0,
        9,
        menu->title()
    );

    u8g2.drawHLine(
        0,
        11,
        128
    );

    for (
        uint8_t i = 0;
        i < menu->count();
        ++i
    ) {
        MenuItem& item =
            menu->item(i);

        const uint8_t y =
            FIRST_ROW +
            (i * ROW_HEIGHT);

        const bool selected =
            i ==
            menuManager.selectedIndex();

        if (
            item.type ==
            MenuType::SEPARATOR
        ) {
            u8g2.drawHLine(
                0,
                y - 6,
                128
            );

            continue;
        }

        if (selected) {
            u8g2.drawStr(
                0,
                y,
                ">"
            );
        }

        if (item.label) {
            u8g2.drawStr(
                8,
                y,
                item.label
            );
        }

        if (
            !item.descriptor ||
            !item.value.ptr
        ) {
            continue;
        }

        char buffer[24];

        const char* value =
            item.descriptor->format(
                item.value,
                buffer,
                sizeof(buffer)
            );

        if (!value) {
            continue;
        }

        const uint8_t valueWidth =
            u8g2.getStrWidth(
                value
            );

        const uint8_t valueX =
            128 -
            valueWidth;

        if (
            selected &&
            menuManager.isEditing()
        ) {
            u8g2.drawStr(
                valueX - 6,
                y,
                "["
            );

            u8g2.drawStr(
                valueX,
                y,
                value
            );

            u8g2.drawStr(
                124,
                y,
                "]"
            );
        } else {
            u8g2.drawStr(
                valueX,
                y,
                value
            );
        }
    }
}
```

---

## Rendu en mode `Browsing`

```text
Settings
──────────────────────────────
  Enabled              ON
> Tempo               120
  Volume             0.75
  MIDI
  Reset
```

Le `>` indique l'item actuellement sélectionné.

Le `MenuManager` fournit :

```cpp
menuManager.selectedIndex()
```

Le `Screen` décide comment représenter cette sélection.

---

## Rendu en mode `Editing`

Après :

```cpp
menuManager.enter();
```

le `Screen` peut afficher :

```text
Settings
──────────────────────────────
  Enabled              ON
> Tempo              [120]
  Volume             0.75
  MIDI
  Reset
```

Après :

```cpp
menuManager.next();
```

```text
Settings
──────────────────────────────
  Enabled              ON
> Tempo              [121]
  Volume             0.75
  MIDI
  Reset
```

Après :

```cpp
menuManager.back();
```

```text
Settings
──────────────────────────────
  Enabled              ON
> Tempo               121
  Volume             0.75
  MIDI
  Reset
```

Les crochets sont uniquement une convention du renderer.

Le `MenuManager` fournit seulement :

```cpp
menuManager.isEditing()
```

---

## Afficher les valeurs alignées à droite

Le renderer peut utiliser `U8g2::getStrWidth()` :

```cpp
const uint8_t valueWidth =
    u8g2.getStrWidth(
        value
    );

const uint8_t x =
    128 -
    valueWidth;

u8g2.drawStr(
    x,
    y,
    value
);
```

Cela donne :

```text
Enabled              ON
Tempo               120
Volume             0.75
Clock            Internal
```

Le renderer n'a pas besoin de connaître la longueur de la valeur.

---

## Les types sont transparents pour le renderer

Le renderer appelle simplement :

```cpp
item.descriptor->format(
    item.value,
    buffer,
    sizeof(buffer)
);
```

Il peut donc afficher :

```text
BOOL      ON
INT       120
FLOAT     0.75
ENUM      MIDI
```

Le renderer ne doit pas avoir de logique spécifique du type :

```cpp
if (type == BOOL) ...
if (type == INT) ...
if (type == ENUM) ...
```

Le `Descriptor` s'occupe du formatage.

---

## Rendu d'un ENUM

Menu initial :

```text
MIDI
──────────────────────────────
> Clock          Internal
  Channel              1
```

Après `enter()` :

```text
MIDI
──────────────────────────────
> Clock        [Internal]
  Channel              1
```

Après `next()` :

```text
MIDI
──────────────────────────────
> Clock             [MIDI]
  Channel              1
```

Après `back()` :

```text
MIDI
──────────────────────────────
> Clock               MIDI
  Channel              1
```

La logique de changement de valeur appartient au `EnumDescriptor`. U8g2 ne fait qu'afficher le texte produit par le descriptor.

---

## Rendu d'un sous-menu

Menu parent :

```text
Settings
──────────────────────────────
  Tempo               120
> MIDI
  Audio
  Reset
```

Après :

```cpp
menuManager.enter();
```

le menu courant devient `MIDI` :

```text
MIDI
──────────────────────────────
> Clock          Internal
  Channel              1
  Mode                MIDI
```

Après :

```cpp
menuManager.back();
```

le menu parent est restauré :

```text
Settings
──────────────────────────────
  Tempo               120
> MIDI
  Audio
  Reset
```

La sélection `MIDI` est restaurée par la pile de navigation.

---

## `LABEL` et `SEPARATOR`

Exemple :

```cpp
menu.addLabel(
    "General"
);

menu.addBool(
    "Enabled",
    &enabled,
    &enabledDescriptor
);

menu.addSeparator();

menu.addLabel(
    "Audio"
);

menu.addFloat(
    "Volume",
    &volume,
    &volumeDescriptor
);
```

Rendu :

```text
Settings
──────────────────────────────
  General
> Enabled              ON
──────────────────────────────
  Audio
  Volume             0.75
```

Un `LABEL` peut servir de titre de section.

Un `SEPARATOR` peut être rendu avec :

```cpp
u8g2.drawHLine(
    0,
    y - 6,
    128
);
```

---

## Scrolling sur un écran 128×64

Un menu peut contenir plus d'items que l'écran ne peut en afficher :

```text
Settings
──────────────────────────────
> Item 0
  Item 1
  Item 2
  Item 3
  Item 4
  Item 5  ← hors écran
```

Le `MenuManager` peut avoir :

```cpp
selectedIndex = 7;
```

Le `Screen` décide alors quelle partie du menu est visible :

```text
Settings
──────────────────────────────
  Item 5
  Item 6
> Item 7
  Item 8
  Item 9
```

Le scrolling est donc une responsabilité du `Screen`.

Une logique typique :

```cpp
constexpr uint8_t VISIBLE_ROWS = 5;

if (
    selectedIndex <
    firstVisible
) {
    firstVisible =
        selectedIndex;
}

if (
    selectedIndex >=
    firstVisible +
    VISIBLE_ROWS
) {
    firstVisible =
        selectedIndex -
        VISIBLE_ROWS +
        1;
}
```

Le `MenuManager` continue de connaître l'index réel de l'item sélectionné.

Le renderer dessine uniquement la fenêtre visible.

---

## Intégration avec les événements du Screen

```cpp
void SettingsScreen::onNext()
{
    if (menuActive()) {
        menuManager.next();

        requestRedraw();

        return;
    }

    // Navigation normale
}
```

```cpp
void SettingsScreen::onPrev()
{
    if (menuActive()) {
        menuManager.prev();

        requestRedraw();

        return;
    }

    // Navigation normale
}
```

```cpp
void SettingsScreen::onEnter()
{
    if (menuActive()) {
        menuManager.enter();

        requestRedraw();

        return;
    }

    // Action normale
}
```

```cpp
void SettingsScreen::onBack()
{
    if (menuActive()) {
        menuManager.back();

        requestRedraw();

        return;
    }

    // Retour normal
}
```

Le flux devient :

```text
ENCODER / BUTTON
       │
       ▼
    SCREEN
       │
       ├── menuManager.next()
       ├── menuManager.prev()
       ├── menuManager.enter()
       └── menuManager.back()
              │
              ▼
          drawMenu()
              │
              ▼
            U8g2
              │
              ▼
          SSD1306 128×64
```

Cette architecture permet de conserver une bibliothèque de menus indépendante de U8g2 tout en ayant un rendu parfaitement adapté à ton écran OLED.


# Architecture recommandée dans un Screen

Exemple :

```cpp
class SettingsScreen {
public:
    Menu settings;
    Menu midi;
    MenuManager manager;

    SettingsScreen()
        : settings("Settings"),
          midi("MIDI")
    {
        setupMenu();

        manager.begin(&settings);
    }

private:
    void setupMenu()
    {
        settings.addSubmenu(
            "MIDI",
            &midi
        );
    }
};
```

Le `MenuManager` navigue.

Le `Screen` reçoit les événements.

Le renderer du `Screen` dessine.

```text
INPUT
  │
  ▼
SCREEN
  │
  ▼
MENU MANAGER
  │
  ├── sélection
  ├── édition
  ├── push/pop
  │
  ▼
MENU / VALUES
  │
  ▼
RENDERER
  │
  ▼
DISPLAY
```

Cette séparation permet de changer l'écran ou le système de rendu sans modifier la logique de navigation.
