#pragma once
#include <stdint.h>
class Menu;
class MenuManager;
using MenuCallback = void (*)(MenuManager &);
enum class MenuType : uint8_t
{
    ACTION,
    SUBMENU,
    BOOL,
    INT,
    FLOAT,
    ENUM,
    LABEL,
    SEPARATOR
};
union MenuValue
{
    void *ptr = nullptr;
    bool *b;
    int32_t *i32;
    uint8_t *u8;
    float *f;
};
struct EnumOption
{
    uint8_t value;
    const char *label;
};
struct EnumDescriptor
{
    const EnumOption *options;
    uint8_t count;
};
struct IntDescriptor
{
    int32_t min, max, step;
};
struct FloatDescriptor
{
    float min, max, step;
};
struct MenuItem
{
    const char *label = nullptr;
    MenuType type = MenuType::ACTION;
    MenuValue value{};
    const void *descriptor = nullptr;
    MenuCallback callback = nullptr;
    Menu *submenu = nullptr;
};
