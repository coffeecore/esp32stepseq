#pragma once
#include "Menu.h"
enum class MenuState : uint8_t
{
    Browsing,
    Editing
};
class MenuManager
{
public:
    void setRoot(Menu *m)
    {
        _menu = m;
        _selected = 0;
    }
    bool back()
    {
        if (_state == MenuState::Editing)
        {
            _state = MenuState::Browsing;
            return true;
        }
        if (_menu && _menu->parent)
        {
            _menu = _menu->parent;
            _selected = 0;
            return true;
        }
        return false;
    }

private:
    Menu *_menu = nullptr;
    uint8_t _selected = 0;
    MenuState _state = MenuState::Browsing;
};
