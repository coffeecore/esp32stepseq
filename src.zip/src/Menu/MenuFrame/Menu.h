#pragma once
#include "MenuItem.h"
class Menu
{
public:
    static constexpr uint8_t MAX_ITEMS = 16;
    explicit Menu(const char *t, Menu *p = nullptr) : parent(p), _title(t) {};
    void addItem(const MenuItem &i)
    {
        if (_count < MAX_ITEMS)
        {
            _items[_count++] = i;
            if (i.type == MenuType::SUBMENU && i.submenu)
                i.submenu->parent = this;
        }
    }
    MenuItem &item(uint8_t i) { return _items[i]; }
    uint8_t count() const { return _count; }
    Menu *parent;

private:
    const char *_title;
    MenuItem _items[MAX_ITEMS]{};
    uint8_t _count = 0;
};
