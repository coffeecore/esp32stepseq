#pragma once

#include "Arduino.h"

class Screen;

class Menu;

using MenuCallback = void (*)(Screen&);

enum class MenuType
{
    TYPE_ENUM,
    TYPE_INT,
    TYPE_FLOAT,
    TYPE_ACTION,
    TYPE_SUBMENU
};

struct MenuItem {
    const char* label = nullptr;
    MenuType type = MenuType::TYPE_ACTION;
    void* value = nullptr;
    MenuCallback callback = nullptr;

    Menu* submenu = nullptr;
};

class Menu
{
    public:
        const char* name;
        static constexpr uint8_t MAX_ITEMS = 16;
        MenuItem items[MAX_ITEMS];
        uint8_t itemsCount = 0;
        uint8_t cursor = 0;

        Menu* parent = nullptr;

        void addItem(const MenuItem& item)
        {
            if (itemsCount >= MAX_ITEMS) {
                return;
            }

            items[itemsCount] = item;

            itemsCount++;
        }

        void next() {
            if (itemsCount == 0) {
                return;
            }
            cursor = (cursor + 1) % itemsCount;
        }

        void prev() {
            if (itemsCount == 0) {
                return;
            }
            cursor = (cursor - 1 + itemsCount) % itemsCount;
        }

        MenuItem* selectedItem()
{
    if (itemsCount == 0)
        return nullptr;

    return &items[cursor];
}
};
