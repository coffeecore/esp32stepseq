#pragma once
#include "Menu.h"

class MenuManager
{
public:

    Menu* current;

    void open(Menu* menu)
    {
        current = menu;
    }

    void back()
    {
        current = current->parent;
    }

    void select(Screen& screen)
{
    MenuItem* item = current->selectedItem();

    if (!item)
        return;

    switch(item->type)
    {
        case MenuType::TYPE_SUBMENU:

            if(item->submenu)
                open(item->submenu);

            break;

        case MenuType::TYPE_ACTION:

            if(item->callback)
                item->callback(screen);

            break;

        case MenuType::TYPE_ENUM:

            // édition

            break;

        case MenuType::TYPE_INT:

            // édition

            break;

        default:
            break;
    }
}
};
