#pragma once

#include <Arduino.h>

enum class MenuType : uint8_t
{
    ACTION,
    SUBMENU,
    BOOL,
    INT,
    FLOAT,
    ENUM,
    LABEL,
    SEPARATOR
};

union MenuValue
{
    void *ptr = nullptr;
    bool *b;
    int32_t *i32;
    uint8_t *u8;
    float *f;
};

struct EnumOption
{
    uint8_t value;
    const char *label;
};

struct EnumDescriptor
{
    const EnumOption *options;
    uint8_t count;
};

struct IntDescriptor
{
    int32_t min;
    int32_t max;
    int32_t step;
};

struct FloatDescriptor
{
    float min;
    float max;
    float step;
};
