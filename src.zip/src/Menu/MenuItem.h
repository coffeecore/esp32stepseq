#pragma once

#include <Arduino.h>

#include "MenuTypes.h"

class Menu;
class MenuManager;
using MenuCallback = void (*)(MenuManager &);

struct MenuItem
{
    const char *label = nullptr;
    MenuType type = MenuType::ACTION;
    MenuValue value{};
    const void *descriptor = nullptr;
    MenuCallback callback = nullptr;
    Menu *submenu = nullptr;
};

