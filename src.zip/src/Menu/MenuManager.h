#pragma once

#include <Arduino.h>

enum class MenuState : uint8_t
{
    Browsing,
    Editing
};

class MenuManager
{
    public:
        void setRoot(Menu *menu)
        {
            menu = menu;
            selected = 0;
        }
        bool back()
        {
            if (state == MenuState::Editing) {
                state = MenuState::Browsing;
                return true;
            }

            if (menu && menu->parent) {
                menu = menu->parent;
                selected = 0;
                return true;
            }

            return false;
        }

    private:
        Menu *menu = nullptr;
        uint8_t selected = 0;
        MenuState state = MenuState::Browsing;
};
