#pragma once

#include <Arduino.h>

#include "MenuItem.h"

class Menu
{
    public:
        static constexpr uint8_t MAX_ITEMS = 16;

        explicit Menu(const char *title, Menu *parent = nullptr)
            : parent(parent), title(title)
        {

        };

        void addItem(const MenuItem &i)
        {
            if (itemsCount < MAX_ITEMS) {
                items[itemsCount++] = i;

                if (i.type == MenuType::SUBMENU && i.submenu) {
                    i.submenu->parent = this;
                }
            }
        }
        MenuItem &item(uint8_t i)
        {
            return items[i];
        }
        uint8_t count() const
        {
            return itemsCount;
        }

        Menu* stack[8];

        uint8_t level;
    private:
        const char *title;
        MenuItem items[MAX_ITEMS]{};
        uint8_t itemsCount = 0;
};
