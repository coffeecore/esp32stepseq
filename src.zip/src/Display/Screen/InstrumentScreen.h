#pragma once

#include "Display/Workspace.h"
#include "Sequencer/Sequencer.h"
#include "Display/Screen/Screen.h"
#include "Audio/Notes.h"
#include "Menu/Menu.h"

class InstrumentScreen : public MenuScreen
{
public:
    Menu menu;

    InstrumentScreen(UIState& u,
                     Sequencer& s,
                     U8G2& d,
                     IAudioEngine& a, MenuManager& m)
        : MenuScreen(u, s, d, a)
    {
        MenuItem mi;
        mi.label = "Type";
        mi.type = MenuType::TYPE_ENUM;
        mi.value = a.instruments[s.tracks[uiState.selectedTrack].instrument].source;
        menu.addItem(mi);
        // menu.addItem({"Snare", MenuType::TYPE_CHOICE, nullptr, nullptr});
        // menu.addItem({"Hat", MenuType::TYPE_CHOICE, nullptr, nullptr});
        // menu.addItem({"Clap", MenuType::TYPE_CHOICE, nullptr, nullptr});
    }

    void draw() override
    {

        u8g2.drawStr(6, 0, "== ");
        u8g2.drawStr(6, 15, menu.name);
        u8g2.drawStr(6, 40, " ==");

        char buffer[Constants::SCREEN_WIDTH / u8g2.getMaxCharWidth() + 1];
        for (uint8_t i;i<menu.itemsCount;i++) {
            snprintf(
                buffer,
                sizeof(buffer),
                "%s %s",
                i == menu.cursor ? ">":"",
                menu.items[i].label
            );
            u8g2.drawStr(16, 0, buffer);
        }
    }
};
