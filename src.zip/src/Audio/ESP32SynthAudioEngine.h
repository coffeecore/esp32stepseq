#pragma once

#include <math.h>
#include "ESP32Synth.h"
#include "Constants.h"
#include "IAudioEngine.h"
#include "PlayNoteRequest.h"
#include "Audio/Notes.h"
#include "Sample/SampleLoader.h"

// #include "closed_hihat_44100hz.h"

const SampleZone closed_hihat_44100hz[] = {{c0, g10, 0, c4}};

struct RegisteredSample
{
    uint16_t sampleId;
    uint8_t esp32Id;
};

class ESP32SynthAudioEngine : public IAudioEngine
{
public:
    explicit ESP32SynthAudioEngine(ESP32Synth& _synth, SampleLoader& _sampleLoader)
        : synth(_synth)
        , sampleLoader(_sampleLoader)
    {
    }

    // Si un jour tu trouves que cette recherche est trop fréquente, tu peux ajouter un cache dans ESP32SynthAudioEngine, sans toucher à MyInstrument.

    // Par exemple :

    // ```cpp
    // uint8_t instrumentToEsp32Sample[Constants::NUMBER_OF_INSTRUMENTS];
    // ```

    // Lors de addInstrument() :

    // ```cpp
    // instrumentToEsp32Sample[instrumentsCount] =
    //     registerSample(instrument.sampleId);
    // ```

    // Puis :

    // ```cpp
    // synth.setSample(voice, instrumentToEsp32Sample[instrumentIndex], ...);
    // ```

    // Cette table reste totalement privée au backend ESP32Synth. Si tu écris un autre moteur audio, il aura sa propre structure interne et MyInstrument ne changera pas.

    RegisteredSample registered[MAX_SAMPLES];
    uint8_t registeredCount = 0;

    void begin() override
    {
        // synth.begin(...) reste fait dans setup_audio() comme aujourd'hui.
        for (uint8_t i = 0; i < Constants::NUMBER_OF_VOICES; i++) {
            voiceActive[i] = false;
        }
    }

    int8_t findRegisteredSample(uint16_t sampleId)
    {
        for (uint8_t i = 0; i < registeredCount; i++) {
            if (registered[i].sampleId == sampleId)
                return registered[i].esp32Id;
        }

        return -1;
    }

    void updateInstrument(uint8_t index, const MyInstrument& instrument)
    {
        instruments[index] = instrument;

        if (instrument.source == InstrumentSource::Sample)
            addSample(instrument.sampleId);
    }

    void addSample(uint16_t sampleId)
    {
        MySample* sample = sampleLoader.getSampleById(sampleId);

        if (sample == nullptr) {
            return;
        }
        if (findRegisteredSample(sampleId) >= 0) {
            return;
        }

        if (registeredCount >= MAX_SAMPLES) {
            return;
        }
        uint8_t esp32Id = registeredCount++;

        registered[esp32Id] = {sampleId, esp32Id};

        synth.registerSample(esp32Id, sample->data, sample->length, sample->rate, c4);
    }

    void addInstrument(const MyInstrument& instrument)
    {
        if (instrumentsCount >= Constants::NUMBER_OF_INSTRUMENTS) {
            return;
        }

        instruments[instrumentsCount] = instrument;
        if (instrument.source == InstrumentSource::Sample) {
            addSample(instrument.sampleId);
        }
        instrumentsCount++;
    }

    VoiceHandle play(const PlayNoteRequest& request) override
    {
        uint8_t voice = allocateVoice();

        uint8_t instrumentIndex = request.instrument;
        if (instrumentIndex >= Constants::NUMBER_OF_INSTRUMENTS) {
            instrumentIndex = 0; // fallback sûr plutôt qu'un accès hors tableau
        }

        MyInstrument& inst = instruments[instrumentIndex];

        if (inst.source == InstrumentSource::Sample) {
            voiceSource[voice] = InstrumentSource::Sample;

            // TODO: nom de fonction NON confirmé — je n'ai pas trouvé la
            // signature exacte pour jouer un sample chargé en RAM
            // (distinct de playStream() qui lit depuis la SD en flux).
            // MAX_SAMPLES existe dans ESP32Synth_Config.hpp donc la
            // fonctionnalité existe, mais remplace l'appel ci-dessous par
            // la vraie signature trouvée dans ton ESP32Synth.h local.
            //
            // Attendu : un identifiant de sample pré-chargé (ex: via
            // synth.loadSample(index, data, length) fait une fois au
            // setup()), puis ici on le déclenche sur la voix :
            if (!applyInstrumentSample(voice, inst)) {
                return VoiceHandle{};
            }

            applyCommands(voice, request);

            uint32_t freqCentiHz = notesFreq[request.note];
            Serial.println("ESP32 SYTNH NOTE ON SAMPLE");
            synth.noteOn(voice, freqCentiHz, request.velocity);
        }
        else {
            voiceSource[voice] = InstrumentSource::Wave;

            applyInstrument(voice, inst);
            applyCommands(voice, request);

            uint32_t freqCentiHz = notesFreq[request.note];
            Serial.println("ESP32 SYTNH NOTE ON WAVE");
            synth.noteOn(voice, freqCentiHz, request.velocity);
        }

        voiceActive[voice] = true;

        return VoiceHandle{voice};
    }

    void stop(VoiceHandle voice) override
    {
        if (!voice.valid() || voice.id >= Constants::NUMBER_OF_VOICES) {
            return;
        }

        // TODO: pour le cas Sample, je n'ai pas trouvé de stopStream()
        // confirmé dans la doc consultée. Vérifie dans ton ESP32Synth.h
        // local s'il en existe une ; sinon noteOff(voice) coupe peut-être
        // aussi un stream (comportement à vérifier empiriquement).
        Serial.println("ESP32 SYTNH NOTE OFF");
        synth.noteOff(voice.id);
        voiceActive[voice.id] = false;
    }

private:
    ESP32Synth& synth;
    SampleLoader& sampleLoader;

    bool voiceActive[Constants::NUMBER_OF_VOICES] = {false};
    InstrumentSource voiceSource[Constants::NUMBER_OF_VOICES] = {InstrumentSource::Wave};
    uint8_t nextVoice = 0;

    // Alloue une voix : prend la prochaine libre, ou vole la plus ancienne
    // (round-robin) si le pool est saturé. Toujours bornée à
    // Constants::NUMBER_OF_VOICES, jamais d'incrément infini.
    uint8_t allocateVoice()
    {
        for (uint8_t i = 0; i < Constants::NUMBER_OF_VOICES; i++) {
            uint8_t candidate = (nextVoice + i) % Constants::NUMBER_OF_VOICES;

            if (!voiceActive[candidate]) {
                nextVoice = (candidate + 1) % Constants::NUMBER_OF_VOICES;
                return candidate;
            }
        }

        // Aucune voix libre : vol de la plus ancienne (round-robin actuel).
        uint8_t stolen = nextVoice;
        synth.noteOff(stolen);
        nextVoice = (nextVoice + 1) % Constants::NUMBER_OF_VOICES;

        return stolen;
    }

    // Ne s'applique qu'aux instruments de type Wave (oscillateur interne).
    void applyInstrument(uint8_t voice, const MyInstrument& inst)
    {
        synth.setWave(voice, inst.wave);
        synth.setEnv(voice, inst.adsr.attackMs, inst.adsr.decayMs, inst.adsr.sustainLvl, inst.adsr.releaseMs);
    }

    bool applyInstrumentSample(uint8_t voice, const MyInstrument& inst)
    {
        int8_t esp32SynthSampleId = findRegisteredSample(inst.sampleId);

        if (esp32SynthSampleId < 0) {
            return false;
        }

        synth.setWave(voice, WAVE_SAMPLE);
        synth.setSample(voice, esp32SynthSampleId, inst.sampleLoop, 0, 0);

        synth.setEnv(voice, inst.adsr.state & ATTACK ? inst.adsr.attackMs : 0, inst.adsr.state & DECAY ? inst.adsr.decayMs : 0,
                     inst.adsr.state & SUSTAIN ? inst.adsr.sustainLvl : 255, inst.adsr.state & RELEASE ? inst.adsr.releaseMs : 0);

        return true;
    }

    void applyCommands(uint8_t voice, const PlayNoteRequest& request)
    {
        for (uint8_t i = 0; i < request.commandCount && i < MAX_COMMANDS; i++) {
            const Command& cmd = request.commands[i];

            switch (cmd.type) {
                case CommandType::Arpeggio: {
                    // TODO: vérifie que cet encodage (offsets en demi-tons dans
                    // data[0..2], durée de pas dans data[3]) correspond à ce que
                    // tu mets réellement dans tes Steps. setArpeggio prend des
                    // NOTES explicites (pas des offsets), donc on les recalcule
                    // ici à partir de la note de base.
                    uint32_t n1 = notesFreq[request.note];
                    uint32_t n2 = notesFreq[request.note + cmd.data[0]];
                    uint32_t n3 = notesFreq[request.note + cmd.data[1]];
                    uint32_t n4 = notesFreq[request.note + cmd.data[2]];

                    synth.setArpeggio(voice, cmd.data[3], n1, n2, n3, n4);
                    break;
                }

                case CommandType::Portamento: {
                    // Pas de "setPortamento" dans l'API : on utilise slideFreqTo
                    // vers la note cible, sur la durée donnée par data[0] (ms).
                    uint32_t targetFreq = notesFreq[request.note];
                    synth.slideFreqTo(voice, targetFreq, cmd.data[0]);
                    break;
                }

                case CommandType::Vibrato: {
                    // data[0] = taux LFO en Hz, data[1] = profondeur en Hz
                    synth.setVibrato(voice, cmd.data[0] * 100, cmd.data[1] * 100);
                    break;
                }

                default:
                    break;
            }
        }
    }
};
